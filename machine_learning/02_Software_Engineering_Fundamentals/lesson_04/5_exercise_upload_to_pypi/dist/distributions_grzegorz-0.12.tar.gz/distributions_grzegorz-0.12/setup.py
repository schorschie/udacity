from setuptools import setup

setup(name='distributions_grzegorz',
      version='0.12',
      description='Gaussian distributions',
      packages=['distributions'],
      author='Grzegorz Lippe',
      author_email = 'grzegorz.lippe@posteo.de',
      zip_safe=False)
